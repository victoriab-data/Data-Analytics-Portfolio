# Data Dictionary — NexaTel Communications Churn & Retention Analytics

This dictionary covers the four cleaned tables that feed the Power BI dashboard. All tables were cleaned in MySQL from raw, intentionally messy source data — see the [Data Cleaning Documentation](../Documentation/NexaTel_Data_Cleaning_Documentation.docx) for the full methodology.

---

## 1. Customer_Master
**Grain:** 1 row per customer &nbsp;·&nbsp; **Rows:** 15,000 &nbsp;·&nbsp; **Primary Key:** `Customer_ID`

| Column | Type | Description |
|---|---|---|
| Customer_ID | VARCHAR | Unique customer identifier |
| Gender | VARCHAR | Male / Female |
| Age | INT | Customer age |
| Region | VARCHAR | One of 5 Nigerian regions |
| State | VARCHAR | One of 20 states |
| City | VARCHAR | City of residence (27 clean values) |
| Customer_Segment | VARCHAR | Consumer / SME / Enterprise |
| Senior_Citizen | VARCHAR | Yes / No |
| Dependents | VARCHAR | Yes / No |
| Household_Size | INT | Number of people in household |
| Customer_Since_Date | DATE | Date the customer relationship began |
| Contract_Start_Date | DATE | Current contract start date |
| Contract_End_Date | DATE | Current contract end date |
| Contract_Type | VARCHAR | Month-to-Month / One-Year / Two-Year |
| Number_of_Lines | INT | Number of active lines on the account |
| Device_Type | VARCHAR | Device category |
| Device_Age_Months | INT | Age of primary device in months |
| Internet_Service | VARCHAR | None / DSL / Fiber / 4G LTE / 5G |
| Internet_Plan | VARCHAR | Plan tier (e.g. Basic 10GB, Premium 60GB) |
| Voice_Service | VARCHAR | Voice plan indicator |
| SMS_Plan | VARCHAR | SMS plan indicator |
| International_Calling | VARCHAR | Yes / No |
| Roaming | VARCHAR | Yes / No |
| Streaming_Service | VARCHAR | Yes / No |
| Payment_Method | VARCHAR | 6 standardized payment methods |
| Billing_Method | VARCHAR | Billing method used |
| Churn_Status | VARCHAR | Active / Churned |
| Churn_Date | DATE | Date of churn (NULL if still active) |
| Churn_Reason | VARCHAR | Free-text-style reason for churn (NULL if active) |
| Churn_Category | VARCHAR | Grouped churn reason category |
| Competitor_Available | VARCHAR | Whether a competitor is available in the customer's area |
| Preferred_Competitor | VARCHAR | Named competitor, where applicable (NULL for ~2% of eligible customers — genuine gap, not imputed) |

---

## 2. Monthly_Customer_Activity
**Grain:** 1 row per customer per active month &nbsp;·&nbsp; **Rows:** 300,172 &nbsp;·&nbsp; **Foreign Key:** `Customer_ID`

| Column | Type | Description |
|---|---|---|
| Customer_ID | VARCHAR | Links to Customer_Master |
| Activity_Month | DATE | Month of the activity record |
| Tenure_Months | INT | Customer tenure at time of record |
| Monthly_Data_GB | DECIMAL | Data usage in GB |
| Monthly_Voice_Minutes | DECIMAL | Voice minutes used |
| Monthly_SMS | INT | SMS count |
| International_Minutes | DECIMAL | International call minutes |
| Roaming_Usage_GB | DECIMAL | Roaming data usage |
| Average_Call_Duration | DECIMAL | Average call length |
| Network_Downtime_Minutes | DECIMAL | Network downtime experienced |
| Dropped_Call_Rate | DECIMAL | % of calls dropped |
| Network_Quality_Score | DECIMAL | Network quality rating (~7,500 genuine NULLs) |
| Service_Quality_Score | DECIMAL | Overall service quality rating |
| Customer_Satisfaction_Score | DECIMAL | Monthly satisfaction rating (~7,500 genuine NULLs) |
| Monthly_Charge | DECIMAL | Base monthly charge |
| Additional_Charges | DECIMAL | Extra charges billed |
| Discount | DECIMAL | Discount applied |
| Tax | DECIMAL | Tax applied |
| Total_Monthly_Bill | DECIMAL | Final billed amount (~7,500 genuine NULLs; fixed from text type during cleaning) |
| Payment_Delay_Days | INT | Days payment was delayed |
| Missed_Payments | INT | Count of missed payments |
| Outstanding_Balance | DECIMAL | Balance owed (~7,500 genuine NULLs) |
| Customer_Service_Calls | INT | Number of service calls made |
| Technical_Support_Tickets | INT | Number of support tickets raised |
| Complaint_Count | INT | Number of complaints logged |
| Competitor_Available | VARCHAR | Whether a competitor was available that month |
| Competitor_Name | VARCHAR | NULL whenever Competitor_Available = 'No' (confirmed as valid logic, not a data error) |
| Competitor_Price_Difference | DECIMAL | Price gap vs. competitor (same NULL logic as above) |
| Competitor_Promotion | VARCHAR | Competitor promotion active |
| Competitor_Service_Rating | DECIMAL | Competitor's service rating (same NULL logic as above) |
| Port_Out_Intent | VARCHAR | Signal of customer intent to switch providers |
| Churn_Status | VARCHAR | Status as of this month |
| Network_Downtime_Outlier | VARCHAR | Flag for statistically unusual downtime values |

---

## 3. Customer_Support_Interactions
**Grain:** 1 row per support interaction &nbsp;·&nbsp; **Rows:** 59,142 &nbsp;·&nbsp; **Foreign Key:** `Customer_ID`

| Column | Type | Description |
|---|---|---|
| Interaction_ID | VARCHAR | Interaction identifier (180 legitimate duplicates retained — reopened/escalated tickets) |
| Customer_ID | VARCHAR | Links to Customer_Master |
| Interaction_Date | DATE | Date of the interaction |
| Support_Channel | VARCHAR | Channel used (casing standardized) |
| Issue_Type | VARCHAR | Type of issue raised |
| Issue_Category | VARCHAR | Grouped issue category |
| Resolution_Status | VARCHAR | Outcome of the interaction |
| Resolution_Time_Hours | DECIMAL(10,2) | Time to resolve, in hours |
| Customer_Satisfaction_After_Interaction | DECIMAL(5,2) | Post-interaction satisfaction score |
| Escalated | VARCHAR | Yes / No (real NULLs preserved) |
| Complaint_Flag | VARCHAR | Yes / No |

---

## 4. Retention_Campaigns
**Grain:** 1 row per campaign event &nbsp;·&nbsp; **Rows:** 28,191 &nbsp;·&nbsp; **Primary Key:** `Campaign_ID` &nbsp;·&nbsp; **Foreign Key:** `Customer_ID`

| Column | Type | Description |
|---|---|---|
| Campaign_ID | VARCHAR | Unique campaign event identifier |
| Customer_ID | VARCHAR | Links to Customer_Master |
| Campaign_Date | DATE | Date the campaign offer was made (parsed from 5 mixed formats) |
| Campaign_Type | VARCHAR | Loyalty Campaign / High Value Customer / Contract Renewal / At Risk / Win Back / Network Recovery |
| Offer_Type | VARCHAR | Type of retention offer extended |
| Offer_Value | DECIMAL | Monetary value of the offer (~849 genuine NULLs, ~3%) |
| Contact_Channel | VARCHAR | Channel used to reach the customer |
| Customer_Contacted | VARCHAR | Yes / No |
| Customer_Response | VARCHAR | Interested / Not Interested / No Response / Requested More Info (NULL where not contacted, or a genuine 702-row logging gap where contacted but unrecorded) |
| Offer_Accepted | VARCHAR | Yes / No |
| Retained_After_Offer | VARCHAR | Whether the customer was retained following the offer |
| Retention_Cost | DECIMAL | Cost of the retention offer (~850 genuine NULLs, ~3%) |
| Follow_Up_Date | DATE | Follow-up date, where applicable (parsed from same 5 mixed formats as Campaign_Date) |

---

## Relationships (Power BI Star Schema)

```
Dim_Customer ──┐
               ├──< Fact_Monthly_Activity
Dim_Date ──────┤
               ├──< Fact_Support_Interactions
               └──< Fact_Retention_Campaigns
```

`Customer_Master` feeds `Dim_Customer`. `Dim_Date` is a standalone calendar table joined on `Activity_Month` / `Interaction_Date` / `Campaign_Date`. All three fact tables relate back to `Dim_Customer` via `Customer_ID`.
