# NexaTel Communications — Customer Churn & Retention Analytics

**A full-cycle analytics project: MySQL data cleaning → dimensional modeling → Power BI dashboard**

Prepared by Victoria B. — Data Analyst
Analysis Period: January 2023 – December 2025
Tools: MySQL Workbench · Power BI

---

## 1. Business Background

NexaTel Communications is a telecom service provider serving approximately 15,000 customers across Nigeria. Over the three-year period from January 2023 to December 2025, the business experienced a meaningful volume of customer churn. Leadership wanted a clear, data-backed picture of why customers were leaving, what that churn was costing the business, and whether the company's retention campaigns were actually working.

This project simulates that request end-to-end: a synthetic but realistic dataset was generated to reflect genuine Nigerian telecom market dynamics, deliberately built with the kinds of data quality problems an analyst encounters in real operational exports — duplicates, missing values, inconsistent casing, mixed date formats, and outliers.

## 2. Business Problem

NexaTel's leadership team lacked a consolidated view connecting *who* is churning, *why* they're churning, *what it's costing*, and *whether the money spent trying to stop it is working*. Customer data, usage data, support data, and campaign data lived separately, with no single source pulling them together into decision-ready insight.

## 3. Business Objectives

The analysis was scoped around four questions:

1. **Diagnose churn** — Which customer segments, contract types, and service conditions are most associated with churn?
2. **Quantify impact** — How much recurring revenue is at risk, and what is the lifetime value being lost?
3. **Evaluate retention** — Are retention campaigns reaching the right customers, and is their cost justified by the revenue they save?
4. **Recommend action** — What should the business actually do to reduce churn and improve retention ROI?

## 4. Dataset Overview

| Metric | Value |
|---|---|
| Customers | ~15,000 |
| Linked tables | 4 |
| Total records | ~450,000 |
| Time span | Jan 2023 – Dec 2025 (36 months) |
| Data quality issues (intentional) | Duplicates, missing values, inconsistent casing/labels, mixed date formats, wrong data types, outliers |

## 5. Data Sources & Tables

| Table | Grain | Rows (Clean) | Captures |
|---|---|---|---|
| **Customer_Master** | 1 row per customer | 15,000 | Customer profile, contract/service details, billing setup, final churn outcome |
| **Monthly_Customer_Activity** | 1 row per customer per active month | 300,172 | Usage, network quality, billing, payment behavior, competitor pressure signals, tracked monthly |
| **Customer_Support_Interactions** | 1 row per support interaction | 59,142 | Support channel, issue type, resolution outcome |
| **Retention_Campaigns** | 1 row per campaign event | 28,191 | Retention offers extended, customer response, cost of the offer |

Full column-level definitions are in the [Data Dictionary](../Data_Dictionary/Data_Dictionary.md). Sample data (500 rows per table) is in [`/Data_Samples`](../Data_Samples).

**Churn lifecycle logic:** `Customer_Master` holds the final outcome (Churn_Status, Churn_Date, Churn_Reason, Churn_Category). `Monthly_Customer_Activity` tracks status month by month — the churn month is the customer's final record, after which status flips to "Churned" and no further activity is generated. Active customers carry NULL churn fields and continuous monthly records through their most recent active month.

## 6. Data Cleaning & Preparation

All cleaning was done in MySQL Workbench using a staging-table approach, so raw data was never overwritten — every transformation is auditable back to source. Full write-up: [Data Cleaning Documentation](./NexaTel_Data_Cleaning_Documentation.docx). SQL query-and-result evidence: [`/SQL_Evidence`](../SQL_Evidence).

**Approach used across all four tables:** profile first, never assume; verify anything a data dictionary flags rather than taking it at face value; only fix what's actually broken.

| Table | Key Cleaning Work |
|---|---|
| Customer_Master | Removed 40 duplicates · standardized Gender (6→2 values), Region (15→5), State (~60→20), City, Contract_Type (12→3) · fixed mixed Yes/No + 1/0 encodings · parsed 4 date columns across 5 mixed formats · removed age outliers |
| Monthly_Customer_Activity | Removed 300 duplicates · confirmed ~90–95K "missing" competitor fields were valid business logic (NULL only when `Competitor_Available = 'No'`), not errors |
| Customer_Support_Interactions | Verified numeric/categorical validity across the board · retained 180 intentional duplicate Interaction_IDs (reopened/escalated tickets) · cast Resolution_Time_Hours and Customer_Satisfaction_After_Interaction to proper DECIMAL types |
| Retention_Campaigns | Removed 90 duplicates · resolved 5 mixed date formats — including proving, via a REGEXP check for months >12, that the slash format was DD/MM/YYYY (Nigerian convention) and the dash format was MM/DD/YYYY (US convention) — then validated with a zero-unmatched-format count across all 28,281 rows |

A few things that initially looked like data quality problems — the competitor-field nulls, some flagged categorical casing — turned out on inspection to be either correct business logic or already clean. The documentation reflects that distinction rather than "fixing" things that didn't need it.

## 7. Data Modeling

The cleaned tables were loaded into Power BI and structured into a star schema:

```
Dim_Customer ──┐
               ├──< Fact_Monthly_Activity
Dim_Date ──────┤
               ├──< Fact_Support_Interactions
               └──< Fact_Retention_Campaigns
```

A `_Measures` table was created to house all DAX measures separately from the data tables, and a dark custom theme (`NexaTel_Dark_Theme.json`) was applied for visual consistency across all four dashboard pages.

## 8. Power BI Analysis

DAX measures were built to support time intelligence (monthly trends across the 36-month window) and the KPI set below, layered on top of the star schema. Relationship view: [`06_PowerBI_Data_Model_Relationships.png`](../SQL_Evidence/06_PowerBI_Data_Model_Relationships.png).

## 9. Key Performance Indicators

| Group | KPIs |
|---|---|
| **Customer** | Churn Rate % · Retention Rate % · Average Customer Tenure |
| **Revenue** | Monthly Recurring Revenue (MRR) · Average Revenue Per User (ARPU) · Revenue Lost to Churn · Customer Lifetime Value (CLV) |
| **Service** | Network Quality Score · Customer Satisfaction · Complaint Rate |
| **Retention** | Campaign Success Rate · Retention Cost vs. Revenue Saved · Retention ROI |

## 10. Dashboard Pages

**Page 1 — Executive Overview**
Headline business health: Total Customers (15K), Churned Customers (4K), Active Customers (11K), Avg Monthly Bill ($61.46), Churn Rate (25.41%), Retention Rate (74.59%), churn by contract type, churn by internet service, and a monthly churned/churn-rate trend line from Jan 2023–Dec 2025.

**Page 2 — Customer & Churn Drivers**
Why customers are leaving: churn rate by tenure group, customer segment, and internet plan; churned customers broken out by specific churn reason; filterable by customer segment.

**Page 3 — Revenue & Customer Value**
Financial impact: Revenue Lost to Churn ($222.73K), CLV (1.17K), ARPU ($61.46), MRR ($18.0M), Avg Tenure (19.01 months); revenue and value broken out by customer segment; monthly billing trend.

**Page 4 — Retention Campaign Performance**
Campaign effectiveness: Retention ROI (42.92), Revenue Saved ($8.72M), Total Retention Cost ($198K), Customers Retained (7K), Campaign Success Rate (0.42); performance by campaign type; cost vs. revenue value; recommended actions panel.

Full-resolution screenshots of all four pages: [`/Dashboard_Screenshots`](../Dashboard_Screenshots).

## 11. Key Findings & Insights

- **Churn is heavily front-loaded.** 82.77% of churn happens within a customer's first 6 months, dropping to just 4.95% for customers with 25–36 months of tenure. Early-stage retention matters far more than late-stage retention.
- **Consumer segment carries the largest financial exposure.** Of the $222.73K in total revenue lost to churn, Consumer customers account for ~$162K — by far the largest share, despite Enterprise customers having the highest individual CLV (1,873 vs. 1,101 for Consumer).
- **Billing issues are the #1 stated churn reason.** "Unexpected billing charges" (340) and "Monthly charges too high" (333) outrank competitor pressure ("Found cheaper competitor," 329) as the leading drivers of churn.
- **No internet service correlates with the highest churn.** Customers with no internet service churn at 29.80% — higher than any specific internet plan, including Premium 60GB (25.11%).
- **Retention campaigns are working, but unevenly.** Overall retention ROI sits at 42.92, with $8.72M in revenue saved against $198K in retention cost. High Value Customer, Loyalty, and Contract Renewal campaigns post the best success rates (~0.46–0.47), while Win Back campaigns lag well behind (0.29).

## 12. Business Recommendations

1. **Prioritize onboarding and early-tenure engagement.** With 82.77% of churn occurring in the first 6 months, retention spend is likely more effective when front-loaded into the first two quarters of a customer's lifecycle rather than spread evenly.
2. **Fix billing transparency.** Billing-related complaints are the top two churn reasons combined. A clearer, more predictable billing experience could address more churn than any competitor-facing offer.
3. **Scale High Value, Loyalty, and Contract Renewal campaigns**, which are already delivering the strongest success rates, and re-evaluate the Win Back campaign approach, which is underperforming.
4. **Protect the Consumer segment specifically.** It's not the highest-value segment per customer, but it's the largest source of total revenue loss — targeted retention offers here have the biggest aggregate payoff.

## 13. Tools Used

- **MySQL Workbench** — data cleaning, staging tables, validation queries
- **Power BI** — star-schema data modeling, DAX measures, dashboard design
- **Power Query** — data type corrections and shaping
- Custom dark theme design for visual consistency

## 14. Project Outcome

A four-page, fully interactive Power BI dashboard that takes a stakeholder from "what's happening" (Executive Overview) through "why" (Churn Drivers), "what it's costing" (Revenue & Customer Value), to "what to do about it" (Retention Campaign Performance) — backed by an auditable, documented MySQL cleaning process across ~450,000 raw records.

## 15. Conclusion

This project demonstrates a complete, real-world analytics workflow: generating and understanding a messy dataset, cleaning it defensibly in SQL with evidence at every step, modeling it properly for BI, and translating the results into a dashboard a non-technical stakeholder could act on. The findings — front-loaded churn risk, billing as the top churn driver, and uneven campaign ROI — are the kind of insight a telecom retention team could put into action immediately.
